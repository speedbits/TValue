package com.reitplace.old;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.DatabaseMetaData;

/**
 *
 * @author sqlitetutorial.net
 */
public class SQLLiteTest {
    /**
     * Connect to a sample database
     */
    public static void connect() {
        Connection conn = null;
        try {
            //
            // db parameters
            String url = "jdbc:sqlite:/Users/sgali@us.ibm.com/Downloads/hgtvdb/hgtv.db";
            // create a connection to the database
            conn = DriverManager.getConnection(url);

            System.out.println("Connection to SQLite has been established.");

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }
    }

    public static void createNewDatabase(String fileName) {

        String url = "jdbc:sqlite:" + fileName;

        try {
            Connection conn = DriverManager.getConnection(url);
            if (conn != null) {
                DatabaseMetaData meta = conn.getMetaData();
                System.out.println("The driver name is " + meta.getDriverName());
                System.out.println("A new database has been created.");
            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        String dbFilePath = "/Users/sgali@us.ibm.com/Downloads/hgtvdb/hgtv.db";
        File file  = new File(dbFilePath);
        if (file.exists()) {
            System.out.println("DB File exists, connecting....");
            connect();
        } else {
            System.out.println("DB File DOES NOT exist, creating....");
            createNewDatabase(dbFilePath);
        }
    }
}

