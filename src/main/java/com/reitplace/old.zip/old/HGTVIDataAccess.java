package com.reitplace.old;

import java.util.ArrayList;

public interface HGTVIDataAccess {
    public void initialize(Config config) throws Exception;

    public void addRecord(Record record) throws Exception;

    public void deleteRecord(Record record) throws Exception;

    public void updateRecord(Record record) throws Exception;

    public Record getRecord(String upc, String aisle, String section) throws Exception;

    public ArrayList<Record> getRecords(String upc, String aisle, String section) throws Exception;
}
