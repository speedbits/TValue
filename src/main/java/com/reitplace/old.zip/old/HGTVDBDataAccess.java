package com.reitplace.old;


import java.sql.Connection;
import java.sql.DriverManager;
import java.util.ArrayList;



public class HGTVDBDataAccess implements HGTVIDataAccess {
    Connection conn = null;

    public void initialize(Config config) throws Exception {

        conn = DriverManager.getConnection(config.dbConfigMap.get("url"),
                config.dbConfigMap.get("user"),
                config.dbConfigMap.get("password"));

    }
    public void addRecord(Record record) throws Exception {

    }

    public void deleteRecord(Record record)  throws Exception {

    }

    public void updateRecord(Record record) throws Exception {

    }

    public Record getRecord(String upc, String aisle, String section) throws Exception {

        return null;
    }

    public ArrayList<Record> getRecords(String upc, String aisle, String section) throws Exception {
        return null;
    }
}
