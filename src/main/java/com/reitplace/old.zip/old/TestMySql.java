package com.reitplace.old;
import java.sql.*;
public class TestMySql {
    static final String DB_URL = "jdbc:mysql://localhost:3306/hgtv";
    static final String USER =  "hgtvusr"; //"root";
    static final String PASS =  "usrtiger";//"mactiger";
    static final String QUERY = "SELECT * FROM INVENTORY";

    public static void main(String[] args) {
        // Open a connection
        try {
            Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);

            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(QUERY);
            // Extract data from result set
            while (rs.next()) {
                // Retrieve by column name
                System.out.print("SECTION: " + rs.getString("LOC_SECTION"));
                System.out.print(", AISLE: " + rs.getString("LOC_AISLE"));
                System.out.print(", UPC: " + rs.getString("UPC"));
                System.out.print(", QTY: " + rs.getString("QTY"));
                System.out.print(", CREATED_AT: " + rs.getString("CREATED_AT"));
                System.out.print(", UPDATED_AT: " + rs.getString("UPDATED_AT"));
                System.out.println(", IS_ACTIVE: " + rs.getString("IS_ACTIVE"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}


